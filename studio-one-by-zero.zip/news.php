<?php include "header.php"; ?>
<section class="inner-page-banner">
	<div class="container-fluid ">
		<div class="row p-0">
			<div class="col-md-12 p-0">
				<img src="images/inner-banner.png" alt="banner img">
			</div>

		</div>
	</div>
</section>
<section class="news-sec py-md-5">
	<div class="container">
		<h2 class="sec-head text-center">News</h2>
		<div class="single-news-sec">
			
			<div class="new-top-sec">
				<div class="date-sec">
					<h2>17</h2>
					<span>May</span>
				</div>
				<div class="date-right-sec">
					<h2 class="sec-head">Lorem Ipsum is simply </h2>
					<span>ART</span>
				</div>
			</div>
			<div class="news-cont-wrap">
				<img src="images/news1.png" alt="news img">
				<div class="news-btm-cont">
					<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been
						the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley
						of type and scrambled it to make a type specimen book.Lorem Ipsum is simply dummy text of the
						printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever
						since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type
						specimen book. It has survived not only five centuries </p>
				</div>
			</div>
		</div>
		<div class="single-news-sec">
			<div class="new-top-sec">
				<div class="date-sec">
					<h2>17</h2>
					<span>May</span>
				</div>
				<div class="date-right-sec">
					<h2 class="sec-head">Lorem Ipsum is simply </h2>
					<span>ART</span>
				</div>
			</div>
			<div class="news-cont-wrap">
				<img src="images/news1.png" alt="news img">
				<div class="news-btm-cont">
					<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been
						the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley
						of type and scrambled it to make a type specimen book.Lorem Ipsum is simply dummy text of the
						printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever
						since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type
						specimen book. It has survived not only five centuries </p>
				</div>
			</div>
		</div>
		<div class="single-news-sec">
			<div class="new-top-sec">
				<div class="date-sec">
					<h2>17</h2>
					<span>May</span>
				</div>
				<div class="date-right-sec">
					<h2 class="sec-head">Lorem Ipsum is simply </h2>
					<span>ART</span>
				</div>
			</div>
			<div class="news-cont-wrap">
				<img src="images/news1.png" alt="news img">
				<div class="news-btm-cont">
					<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been
						the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley
						of type and scrambled it to make a type specimen book.Lorem Ipsum is simply dummy text of the
						printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever
						since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type
						specimen book. It has survived not only five centuries </p>
				</div>
			</div>
		</div>
	</div>
</section>
<?php include "footer.php"; ?>
<script>


</script>

</body>

</html>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<style>
    .goto-home-wrap {
    height: 100vh;
    text-align: center;
}

.goto-home-wrap a {
    background: blue;
    padding: 10px 20px;
    border-radius: 20px;
    color: #fff;
    text-decoration: none;
}
h1{
    font-size: 150px;
    font-weight: bold;
}
</style>
<body>
    <div class="goto-home-wrap">
        <h1>Oops!</h1>
        <h2>404 - Page Not found</h2>
    <div><a href="#">Go to Homepage</a></div>
    </div>
</body>
</html>